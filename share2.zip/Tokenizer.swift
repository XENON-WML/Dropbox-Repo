//
//  Lex.swift
//  Volcano Workspace
//
//  Created by Xenon Macworld on 11/18/24.
//

import Foundation

extension TCompiler {
    func tokenize(_ code: String) -> [TToken] {
        var result: [TToken] = []
        let tokens = code.replacingOccurrences(of: "\t", with: "'").replacingOccurrences(of: "    ", with: "'").replacingOccurrences(of: "\n", with: "~").toData()
        
        var commands = ["trigger","window", "wait","note","forget","sound","invent","deinvent", "medal","pick","drop","say","set","oscillate","if","else","set","shake","crawl","task","show","hide","profile","setit","stop","click","rclick","put","flash","phase","switch","savenote","particle","macro","done","tofront","fsavenote","msg","stage","play","fixcoords"]
        commands.append(contentsOf: TGame.commands.map { $0.identifier })
        let operators = ["+","-","/","*",">","<","="].map { Character($0) }
        var index = 0

        var config: (
            ignoreMembers: Bool,
            ignoreNumbers: Bool,
            ignoreCommands: Bool,
            ignoreTitledBlocks: Bool,
            ignoreLine: Bool,
            treatIdentifiersAsStrings: Bool,
            notAllowNumbersInIdentifiers: Bool
        ) = (false,false,false,false,false,false, false)
        
        while let char = consumeCurrent() {
            if !config.ignoreLine {
                if char.isLetter || (["@","#"].contains(char) && config.ignoreTitledBlocks) {
                    lexString(char)
                    
                } else if char.isNumber {
                    if !config.ignoreNumbers {
                        var num = String(char)
                        while let next = consumeCurrent(), next.isNumber || next == "." {
                            num.append(next)
                        }
                        if let negative = result.popLast() {
                            if negative == .operator("-") {
                                switch result.last {
                                case .operator, .semicolon:
                                    num = "-\(num)"
                                default : result.append(negative)
                                }
                            } else {
                                result.append(negative)
                            }
                        }
                        
                        if let num = Double(num) {
                            unadvance()
                            result.append(.number(String(num)))
                        }
                    } else {
                        lexString(char)
                    }
                    
                } else if operators.contains(char) {
                    let next = current()
                    
                    if char == "-", next == "-" {
                        config.ignoreLine = true
                    } else {
                        if [">","<"].contains(char) {
                            switch next {
                            case "=":
                                advance()
                                result.append(.operator(String(char) + "="))
                            case ">" where char == "<":
                                advance()
                                result.append(.operator(String(char) + ">"))
                            default:
                                result.append(.operator(String(char)))
                            }
                        } else {
                            result.append(.operator(String(char)))
                        }
                    }
                    
                } else if ["\"","@","#"].contains(char) {
                    let isString = char == "\""
                    var str = ""
                    
                    while let next = consumeCurrent(), next != char {
                        str.append(next)
                    }
                    
                    result.append(isString ? .string(str) : .blockTitle(str))
                } else if ["}","{","[","]","(",")",";","|"].contains(char) {
                    if let pr = TToken(rawValue: String(char)) {
                        result.append(pr)
                        if pr == .leftBrace || pr == .leftBracket { result.append(.endOfStatement) }
                    }
                } else if char == "~" {
                    resetConfiguration()
                    result.append(.lineBreak)
                    result.append(.endOfStatement)
                } else if char == "," && result.last != .lineBreak && result.last != .endOfStatement && !config.ignoreLine {
                    resetConfiguration()
                    //result.append(.lineBreak)
                    result.append(.endOfStatement)
                } else if char == "'" {
                    result.append(.tab)
                }
            } else if char == "~"  {
                resetConfiguration()
                result.append(.lineBreak)
                result.append(.endOfStatement)
            }
        }
        
        result.append(.eof)
        
        log("""
        
        --------------------------
        
        🥁 Final result:
        
        """)
        
        for (index, token) in result.enumerated() {
            print("[\(index)] \(token)")
        }
        
        return result
        
        // MARK: Helper functions
        
        func lexString(_ char: Character) {
            let startIndex = index
            var word = String(char)
            
            while let current = current(), (current.isLetter || (current.isNumber && !config.notAllowNumbersInIdentifiers) || (["-","_","@","#","%","/"].contains(current)) || config.ignoreMembers && current == ".") {
                word.append(current)
                advance()
            }
            if isRandomKeyword(word) {
                index = startIndex
                result.append(.identifier("r"))
                return
            }
            
            if commands.contains(word) && !config.ignoreCommands && !(result.last == .operator(".")) {
                result.append(.command(word))
                setParams(for: word)
                config.ignoreCommands = true
                config.ignoreTitledBlocks = true
            } else if word == "breakpoint" {
                result.append(.breakpoint)
            } else if ["true","false"].contains(word) && peekPrevious() != "." {
                result.append(.booleanLiteral(Bool(word) ?? false))
            } else if ["and","or","not"].contains(word) {
                result.append(.operator(word))
            } else {
                result.append(config.treatIdentifiersAsStrings ? .string(word) : .identifier(word))
            }
            if current() == "." {
                result.append(.operator("."))
            }
        }
        
        func peekPrevious() -> Character? {
            if tokens.indices.contains(index - 1) {
                return tokens[index-1].toCharacter()
            }
            return nil
        }
        func peekNext() -> Character? {
            if tokens.indices.contains(index + 1) {
                return tokens[index+1].toCharacter()
            }
            return nil
        }
        func current() -> Character? {
            if index < tokens.count {
                return tokens[index].toCharacter()
            }
            return nil
        }
        func consumeCurrent() -> Character? {
            if index < tokens.count {
                let token = tokens[index].toCharacter()
                advance()
                return token
            }
            return nil
        }
        func advance() {
            index += 1
        }
        func unadvance() {
            if index+1 < tokens.count {
                index -= 1
            }
        }
        func unwrapIdentifier(_ target: TToken) -> String? {
            if case .identifier(let string) = target {
                return string
            }
            return nil
        }
        
        
        func isRandomKeyword(_ input: String) -> Bool {
            let pattern = #"^r\d+"#
            return input.range(of: pattern, options: .regularExpression) != nil
        }
        
        func setParams(for command: String) {
            switch command {
            case "note","sound","forget","say","window","switch","flash","play","task","msg":
                config.ignoreMembers = true
                config.ignoreNumbers = true
                config.treatIdentifiersAsStrings = true
    
            default:
                break
            }
        }
        func resetConfiguration() { config = (false,false,false,false,false,false,false) }
    }
}

